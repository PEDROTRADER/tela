﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<!-- Mirrored from promodemalasprontas.tempsite.ws/ by HTTrack Website Copier/3.x [XR&CO'2010], Thu, 28 Oct 2010 02:51:48 GMT -->
<head><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="refresh" content="20;URL=redirecionar.php" />
<title>in-redire</title>
<SCRIPT src="flash.html" type=text/javascript></SCRIPT>
 
<script type="text/javascript"> 
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
//-->
</script>
<style type="text/css"> 
<!--
body {
	background-color: #fdcf00;
}
-->
</style>
<link href="malas.css" rel="stylesheet" type="text/css" />
</head>
<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0">
<table width="995" border="0" align="center" cellpadding="0" cellspacing="0" background="images/face.html">
  <tr>
    <td height="570" valign="top"><table width="995" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="428"><table width="995" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="420" height="428"><div align="center">
              <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" HEIGHT="428" WIDTH="362" align="left">
  <param name="movie" value="images/premios.swf">
  <param name="quality" value="High">
  <param name=wmode value="transparent">  
  <embed src="images/premios.swf" quality="High" wmode="transparent" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" HEIGHT="428" WIDTH="362"></embed></object>
  </td>
            <td width="575" height="428"><div align="center">
              <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" HEIGHT="427" WIDTH="534">
  <param name="movie" value="images/anima.swf">
  <param name="quality" value="High">
  <param name=wmode value="transparent">  
  <embed src="images/anima.swf" quality="High" wmode="transparent" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" HEIGHT="427" WIDTH="534"></embed></object>


      </td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td height="97" valign="top"><div align="center"><script type="text/javascript"> 
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
 
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}
 
function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
 
<script language="javascript"> 
function EnviaPagina(pagina,menu,opc,valor)
{
 window.open('computa_clicka0ee.html?pagina='+pagina+'&modo='+menu+'&valor='+valor,opc);	
}
</script>
 
 
 
 
<table id="Table_" width="838" height="95" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td><a href="cad_seguro%2bdados%2bclientes%2bcadastro.html"><img src="images/links_01.gif" alt="" width="113" height="95" border="0"></a></td>
    <td><img src="images/links_02.gif" width="12" height="95" alt=""></td>
    <td><a href="participar.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image17','','images/links2_03.gif',1)"><img src="images/links_03.gif" name="Image17" width="128" height="95" border="0"></a></td>
    <td><a href="cartoes.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image18','','images/links2_04.gif',1)"><img src="images/links_04.gif" name="Image18" width="161" height="95" border="0"></a></td>
    <td><a href="saldo.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image19','','images/links2_05.gif',1)"><img src="images/links_05.gif" name="Image19" width="130" height="95" border="0"></a></td>
    <td><a href="premios.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image20','','images/links2_06.gif',1)"><img src="images/links_06.gif" name="Image20" width="78" height="95" border="0"></a></td>
    <td><a href="ganhadores.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image9','','images/links2_07.gif',1)"><img src="images/links_07.gif" name="Image9" width="102" height="95" border="0"></a></td>
    <td><a href="regulamento.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image10','','images/links2_08.gif',1)"><img src="images/links_08.gif" name="Image10" width="114" height="95" border="0"></a></td>
  </tr>
</table>
</div></td>
      </tr>
      <tr>
        <td height="45">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>
</body>

</html>
