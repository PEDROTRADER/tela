﻿function putFlash(str) {
	document.write(str);
}